# UVM — Urbit Vere Manager

**One ship. Private access. Explicit control.**

UVM is a Dappnode package for managing one Urbit ship with the official Vere
runtime. It pairs persistent pier storage with a private management interface,
owner-controlled HTTPS and explicit ship Start/Stop controls.

> **Development candidate—not an installable release or approved upgrade.**
> Local source checks pass, but the UVM rename has not been rebuilt/exported or
> accepted on a Dappnode target. Do not install it over an existing ship.

Package identity: `uvm.public.dappnode.eth`. UVM means **Urbit Vere Manager**
here; it is not the separate Urbit Virtual Machine blockchain project.

## What UVM manages

- **One ship:** Vere runs the ship; UVM manages its lifecycle.
- **Private access:** management and ship interfaces use separate HTTPS origins.
- **Owner enrollment:** setup requires owner authority, not merely first access.
- **Persistent storage:** the pier and management state live outside the image.
- **Explicit control:** starting the package does not automatically start a ship.

The container includes the pinned Vere runtime, a Python supervisor and
management UI, and Nginx for private HTTPS. Ship HTTP stays on loopback inside
the container. There is no public administration port or third-party certificate
service.

UVM does not automatically create a ship, accept boot-key uploads, select an
arbitrary pier directory or start a ship after installation or import.

## Private interfaces

| Interface | Configured HTTPS origin | Purpose |
| --- | --- | --- |
| Manager | `https://uvm.public.dappnode.private:8443` | Owner enrollment and ship management |
| Ship | `https://ship.uvm.public.dappnode.private:8443` | The running ship's web interface |

The Compose service is `ship`. Separate hostnames keep management and ship
authentication cookies isolated. These are configured endpoints, not a claim
that target DNS, browser trust or installation has passed acceptance.

## Setup model

The intended deployment flow is below. Native certificate transfer and target
acceptance are still pending; this is not an installation quick start.

1. **Configure owner trust.** Prepare the enrollment authority locally and supply
   only its digest, the public owner-CA fingerprint and the two HTTPS origins to
   the setup wizard. The offline preparation page is
   `tools/browser-importer/bootstrap-authority.html`; it stays outside the image.
2. **Provision HTTPS.** Use a trusted, authenticated management channel to obtain
   the package's public CSR and transfer the owner-signed certificate and public
   root certificate. The leaf certificate must cover both configured hostnames.
   Keep the CA private key outside the package.
3. **Enroll the owner.** Establish browser trust and enroll through the private
   manager interface. Never bypass a certificate warning to bootstrap trust.
4. **Prepare the ship separately.** Existing-pier migration or import and explicit
   Start are separate operations, not side effects of installation or enrollment.

On fresh storage, the package waits for certificate provisioning without starting
a ship. Do not share enrollment authority, ship keys, credentials or pier contents
with an agent or commit them to the repository. See the
[release and stopped-target acceptance path](docs/release-path.md) for the exact
public-file exchange and remaining gates.

## Storage and existing ships

The Compose volume key is `ship_data`, mounted at `/urbit`. The managed layout
contains `pier`, `uploads` and `control` directories. A **pier** is the ship's
persistent state; **ship** names the service and its browser endpoint.

UVM uses a new package namespace. Retaining `ship_data:/urbit` **does not adopt an
old package's volume**. Legacy, partial or unknown layouts are refused rather
than overwritten. Do not rename directories or force-bind an existing volume to
bypass that refusal, and never run two copies of the same ship.

Read [migration and data-preservation boundaries](docs/migration.md) before
planning any use of existing storage. Target migration is not yet qualified.

## Development

Use Node.js 20+ and the locked SDK. Python volume-guard tests require Python 3
with POSIX directory-descriptor support; TLS/supervisor tests use Python 3.13+
and OpenSSL 3. Set `TMPDIR` and `IMPORTER_TEST_SCRATCH` to an existing private
scratch directory before running synthetic tests.

```sh
npm ci --ignore-scripts
npm test
npm run validate
PYTHONDONTWRITEBYTECODE=1 npm run test:volume
python3 -B -m unittest discover -s tests -p test_image_entrypoint_harness.py
python3 -B -m unittest discover -s tests -p test_scratch_configuration.py
```

These are host-side checks, not an image build, upload or ship start. `validate`
checks the manifest, Compose and wizard through the pinned SDK. An existing SDK
installation can be selected with `DAPPNODE_SDK_ROOT`. See
[CONTRIBUTING.md](CONTRIBUTING.md) for issue-linked branches and review scope.

Local-only descriptor preparation is available through `npm run prepare:release`.
It writes a fresh, non-overwriting output with SDK-named assets and a separate
hash inventory; it does not build, sign or upload an image. Follow
[local release preparation](docs/release-preparation.md) for the command,
output contract and image-unbound limitations. Descriptor tests retain their
synthetic fixtures under `IMPORTER_TEST_SCRATCH` (or `RELEASE_TEST_SCRATCH`).

## Validation and release status

- **Source checks pass:** package tests, SDK manifest/Compose/wizard validation,
  host-only image-harness tests and the focused pending-supervisor check cover
  the current UVM identity and `ship` service naming.
- **Earlier image evidence is retained:** the pre-UVM image passed its bounded
  local entrypoint/no-ship gate. Accepted TLS and ship-lifecycle evidence is
  reused, not repeated or presented as a test of the renamed image.
- **Release and target gates remain open:** rebuild/export of the renamed
  candidate, distribution terms, namespace control, signer trust, publication,
  native certificate transfer and Dappnode/private-browser acceptance.

The copied runtime is pinned to Vere 4.6. Its embedded OpenSSL maintenance risk
remains unresolved; the frontend's newer TLS library does not repair it.

See [validation results and limitations](docs/validation.md) for evidence scope
and the [release path](docs/release-path.md) for remaining prerequisites.
Installation, owner enrollment, personal import and ship Start are separate
acceptance steps. No automatic publication workflow is installed.

## Attribution and licensing

This fork modernizes androolloyd's original Urbit Dappnode package. It preserves
upstream history and original author attribution; the repository
name is unchanged. Historical quick-start commands and `releases.json` describe
the upstream package, not a release or installation procedure for UVM.

The inherited manifest's `GPL v3` declaration is preserved. Owner-controlled new
UVM contributions are now declared **GPL-3.0-only** in [LICENSE.md](LICENSE.md),
without overriding inherited or third-party terms. The selected avatar is
[original UVM artwork](docs/artwork.md), replacing the inherited image whose
provenance remains unresolved in Git history. This is not complete binary
distribution clearance.

[Third-party licenses and notices](THIRD_PARTY/README.md) collects component
license texts, pinned-source evidence and explicit coverage gaps. It is a
source-tree notice collection, not yet copied into the runtime image.

The [distribution provenance review](docs/distribution-review.md) records the
inherited declaration and a separate unresolved license-mixing question in the
pinned Vere dependencies. A new UVM license alone would not resolve that question.
