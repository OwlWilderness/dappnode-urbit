"""Explicit importer/runtime lifecycle; import completion never starts a runtime.

API: ManagedImporter(pier, uploads, control, *, runtime_adapter=None, **limits),
start(*, confirmed_stopped=False), stop(), status(), close(). The adapter seam is
launch(ship_fd) -> a Popen-compatible child (poll/terminate/kill/wait(timeout)).
The fd is borrowed for launch only; an adapter must preserve its own child handle.
Any launch exception is uncertain, even if it probably failed before execution.

RUNNING means a launch returned a child, not boot, identity, or health acceptance.
Production launch requires Linux procfs and the pinned official AMD64 binary;
there is no executable-path/hash override, adoption, or automatic recovery API.
Service-owned private storage and a trusted administrator are assumed: these locks
coordinate cooperating writers, not hostile same-UID/root mutation. Quiesce HTTP
requests before close; close joins the existing import worker without its mutex.
Unsettled children/ownership keep both lifetime flocks held and close refuses.
"""
import os
import json
import stat
import uuid
import hashlib
import subprocess
import sys

from importer import Importer, ImportError, private_root


OFFICIAL_SHA256 = '47ad302e8934271dfc00dcdab1d553c6d6460b105e3099ff47e0e4e4231bb26d'


class OfficialRuntimeAdapter:
    """Lazy fixed-binary adapter; construction does no I/O or execution."""

    def launch(self, ship_fd):
        fd = None
        try:
            fd = os.open('/bin/urbit', os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
            info = os.fstat(fd)
            if (not stat.S_ISREG(info.st_mode) or stat.S_IMODE(info.st_mode) & 0o022 or
                    not stat.S_IMODE(info.st_mode) & 0o111):
                raise ValueError()
            digest = hashlib.sha256()
            while True:
                chunk = os.read(fd, 1024**2)
                if not chunk:
                    break
                digest.update(chunk)
            if digest.hexdigest() != OFFICIAL_SHA256:
                raise ValueError()
            after = os.fstat(fd)
            if ((info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns) !=
                    (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns)
                    or not sys.platform.startswith('linux')):
                raise ValueError()
            # Linux procfs executes the hashed inode and resolves the held ship inode.
            # argv[0] stays exactly the fixed official executable; no creation flags.
            return subprocess.Popen(['/bin/urbit', '-t', '-p', '34343', '--http-port', '8081',
                                     '--http-ip', '127.0.0.1',
                                     '--loom', '31', '--snap-time', '2', '--no-dock',
                                     f'/proc/self/fd/{ship_fd}'],
                                    executable=f'/proc/self/fd/{fd}', pass_fds=(fd, ship_fd),
                                    stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                                    stderr=subprocess.DEVNULL, shell=False, close_fds=True,
                                    cwd='/')
        except Exception:
            raise ImportError('Pinned official runtime verification or launch was refused.') from None
        finally:
            if fd is not None:
                os.close(fd)


class ManagedImporter(Importer):
    def __init__(self, pier, uploads, control, *, runtime_adapter=None, **limits):
        self.runtime_adapter = OfficialRuntimeAdapter() if runtime_adapter is None else runtime_adapter
        self.runtime = {'state': 'STOPPED'}
        self.child = None
        self._closing = False
        self._closed = False
        super().__init__(pier, uploads, control, **limits)
        try:
            record = self._load_runtime()
            if record is not None:
                self.runtime = record
                if record['state'] != 'STOPPED':
                    # Preserve the original durable intent; reopen never rewrites it.
                    self.runtime = {'state': 'RECOVERY_REQUIRED'}
        except Exception:
            Importer.close(self)
            raise ImportError('Runtime journal needs operator recovery.') from None

    def _load_runtime(self):
        try:
            fd = os.open('runtime.json', os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK,
                         dir_fd=self.control_fd)
        except FileNotFoundError:
            return None
        with os.fdopen(fd, 'rb') as source:
            info = os.fstat(source.fileno())
            if (not stat.S_ISREG(info.st_mode) or info.st_uid != os.geteuid() or
                    stat.S_IMODE(info.st_mode) & 0o077 or info.st_size > 4096):
                raise ValueError()
            raw = source.read(4097)
            if not raw.lstrip().startswith(b'{'):
                raise ValueError()
            pairs = json.loads(raw, object_pairs_hook=list)
            if len(pairs) != 1 or pairs[0][0] != 'state':
                raise ValueError()
            record = dict(pairs)
        if (set(record) != {'state'} or record['state'] not in
                ('STOPPED', 'STARTING', 'RUNNING', 'FAULT', 'RECOVERY_REQUIRED')):
            raise ValueError()
        return record

    def _persist_runtime(self):
        pending = '.runtime-' + uuid.uuid4().hex
        fd = os.open(pending, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                     0o600, dir_fd=self.control_fd)
        try:
            with os.fdopen(fd, 'w') as output:
                json.dump(self.runtime, output)
                output.flush()
                os.fsync(output.fileno())
            os.replace(pending, 'runtime.json', src_dir_fd=self.control_fd,
                       dst_dir_fd=self.control_fd)
            os.fsync(self.control_fd)
        finally:
            try:
                os.unlink(pending, dir_fd=self.control_fd)
            except FileNotFoundError:
                pass

    def _safe_ship(self):
        ship_fd = None
        try:
            # Check the names still identify our locked inodes, not replacement roots.
            for path, held in ((self.pier, self.pier_fd), (self.control, self.control_fd)):
                current = private_root(path)
                try:
                    first, second = os.fstat(current), os.fstat(held)
                    if (first.st_dev, first.st_ino) != (second.st_dev, second.st_ino):
                        raise ValueError()
                finally:
                    os.close(current)
            if os.listdir(self.pier_fd) != ['ship']:
                raise ValueError()
            ship_fd = os.open('ship', os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW,
                              dir_fd=self.pier_fd)
            marker = os.open('.urb', os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW,
                             dir_fd=ship_fd)
            os.close(marker)
            return ship_fd
        except Exception:
            if ship_fd is not None:
                os.close(ship_fd)
            raise ImportError('Committed pier layout is unsafe; start was refused.') from None

    def start(self, *, confirmed_stopped=False):
        with self.mutex:
            if (self._closed or self._closing or confirmed_stopped is not True or not self.job or
                    self.job['state'] != 'READY_LOCKED' or self.runtime['state'] != 'STOPPED'):
                raise ImportError('Explicit stopped confirmation and an inactive ready import are required.')
            try:
                record = self._load_runtime()
                if record is not None and record != self.runtime:
                    raise ValueError()
            except Exception:
                self.runtime = {'state': 'RECOVERY_REQUIRED'}
                raise ImportError('Runtime journal needs operator recovery.') from None
            ship_fd = self._safe_ship()
            try:
                self.runtime = {'state': 'STARTING'}
                self._persist_runtime()
                self.child = self.runtime_adapter.launch(ship_fd)
                self.runtime = {'state': 'RUNNING'}
                self._persist_runtime()
            except Exception:
                self.runtime = {'state': 'FAULT'}
                try:
                    self._persist_runtime()
                except Exception:
                    pass  # The durable STARTING intent, if committed, also blocks retry.
                raise ImportError('Runtime launch is uncertain; operator recovery is required.') from None
            finally:
                os.close(ship_fd)
            return self.status()

    def stop(self):
        with self.mutex:
            if self._closed:
                raise ImportError('Runtime coordinator is closed.')
            if self.runtime['state'] == 'STOPPED':
                return self.status()
            if self.child is None:
                raise ImportError('Runtime ownership is uncertain; operator recovery is required.')
            try:
                if self.child.poll() is None:
                    self.child.terminate()
                try:
                    self.child.wait(timeout=120)
                except (TimeoutError, subprocess.TimeoutExpired):
                    self.child.kill()
                    self.child.wait(timeout=5)
                self.runtime = {'state': 'STOPPED'}
                self._persist_runtime()
                self.child = None
            except Exception:
                self.runtime = {'state': 'FAULT'}
                try:
                    self._persist_runtime()
                except Exception:
                    pass
                raise ImportError('Runtime stop is uncertain; storage remains locked.') from None
            return self.status()

    def close(self):
        # Joining the import worker while holding its mutex would deadlock.
        with self.mutex:
            if self._closed:
                return
            if self.runtime['state'] in ('FAULT', 'RECOVERY_REQUIRED', 'STARTING') and self.child is None:
                raise ImportError('Runtime ownership is uncertain; storage remains locked.')
            self._closing = True
            try:
                if self.child is not None:
                    self.stop()
            except Exception:
                self._closing = False
                raise
        Importer.close(self)
        with self.mutex:
            self._closed = True

    def status(self):
        with self.mutex:
            result = super().status()
            result['security_gate'] = 'OWNER_SELECTED_OFFICIAL_RISK'
            result['runtime'] = dict(self.runtime)
            result['start_available'] = bool(not self._closed and not self._closing and
                                             self.job and self.job['state'] == 'READY_LOCKED'
                                             and self.runtime['state'] == 'STOPPED')
            return result
