#!/usr/bin/env python3
"""Read public APK metadata from a Docker-save STREAM, never a container.

Only the installed APK database and explicitly selected public notice files are
retained. Image config and legacy layer JSON are skipped, never parsed/copied.
Supported input: legacy Docker-save tar with manifest.json and raw layer.tar.
Unsupported formats fail closed. No pull/build/run/load/export-file operation.
"""
import re
import hashlib
import json
import tarfile

DB_PATH = 'lib/apk/db/installed'
MAX_STREAM = 512 * 1024 * 1024
MAX_LAYER = 256 * 1024 * 1024
MAX_SELECTED = 8 * 1024 * 1024
MAX_MEMBERS = 100000


class Reader:
    """Bound streaming input and optionally hash every raw layer byte."""
    def __init__(self, source, limit, digest=False):
        self.source, self.limit, self.count = source, limit, 0
        self.digest = hashlib.sha256() if digest else None

    def read(self, size=-1):
        size = min(65536, self.limit - self.count + 1) if size < 0 else min(size, self.limit - self.count + 1)
        data = self.source.read(size)
        self.count += len(data)
        if self.count > self.limit:
            raise InventoryError('stream byte limit exceeded')
        if self.digest is not None:
            self.digest.update(data)
        return data

    def drain(self):
        while self.read(65536):
            pass


def safe_path(path):
    path = path.removeprefix('./').rstrip('/')
    if not path or path.startswith('/') or chr(92) in path or any(
            x in ('', '.', '..') for x in path.split('/')) or any(ord(x) < 32 for x in path):
        raise InventoryError('unsafe archive path')
    return path


def layer_view(source, selected):
    reader = Reader(source, MAX_LAYER, True)
    changes, removals = {}, []
    relevant = set(selected)
    for path in selected:
        parts = path.split('/')
        relevant.update('/'.join(parts[:n]) for n in range(1, len(parts)))
    with tarfile.open(fileobj=reader, mode='r|') as tf:
        for count, member in enumerate(tf, 1):
            if count > MAX_MEMBERS:
                raise InventoryError('layer member limit exceeded')
            path = safe_path(member.name)
            parent, _, base = path.rpartition('/')
            if base == '.wh..wh..opq':
                removals.append((parent, True))
                continue
            if base.startswith('.wh.'):
                removals.append(((parent + '/' if parent else '') + base[4:], False))
                continue
            if path not in relevant:
                continue
            if path in changes and not (member.isdir() and changes[path]['kind'] == 'directory'):
                raise InventoryError('ambiguous duplicate selected path')
            kind = 'directory' if member.isdir() else 'regular' if member.isfile() else 'unsupported'
            info = dict(kind=kind, mode=member.mode, uid=member.uid, gid=member.gid, size=member.size)
            if path in selected and member.isfile():
                if member.size > MAX_SELECTED:
                    raise InventoryError('selected file byte limit exceeded')
                content = tf.extractfile(member).read(MAX_SELECTED + 1)
                if len(content) != member.size:
                    raise InventoryError('truncated selected file')
                info.update(content=content, sha256=hashlib.sha256(content).hexdigest())
            changes[path] = info
    reader.drain()
    return dict(sha256='sha256:' + reader.digest.hexdigest(), changes=changes, removals=removals)


def inventory_stream(source, metadata, notice_paths=()):
    """No archive/config extraction; retain only exact selected public files."""
    selected = {DB_PATH, *notice_paths}
    if any(not public_notice(safe_path(p)) for p in notice_paths):
        raise InventoryError('notice path outside public notice allowlist')
    layers, manifest = {}, None
    reader = Reader(source, MAX_STREAM)
    with tarfile.open(fileobj=reader, mode='r|') as tf:
        for count, member in enumerate(tf, 1):
            if count > 1024:
                raise InventoryError('outer member limit exceeded')
            path = safe_path(member.name)
            if re.fullmatch(r'[0-9a-f]{64}/layer.tar', path):
                if not member.isfile() or member.size > MAX_LAYER or path in layers:
                    raise InventoryError('invalid layer member')
                layers[path] = layer_view(tf.extractfile(member), selected)
            elif path == 'manifest.json':
                if manifest is not None or not member.isfile() or member.size > 65536:
                    raise InventoryError('invalid manifest')
                manifest = json.loads(tf.extractfile(member).read(65537))
            # Deliberately do not extract/read image config or legacy layer JSON.
    reader.drain()
    if not isinstance(manifest, list) or len(manifest) != 1:
        raise InventoryError('exactly one legacy image manifest required')
    manifest = manifest[0]
    if manifest.get('Config') != metadata['image_id'].removeprefix('sha256:') + '.json':
        raise InventoryError('manifest image ID mismatch')
    order = manifest.get('Layers')
    if not isinstance(order, list) or len(order) != len(set(order)) or set(order) != set(layers):
        raise InventoryError('manifest layer set mismatch')
    if [layers[n]['sha256'] for n in order] != metadata['layers']:
        raise InventoryError('ordered RootFS layer digest mismatch')
    state = {}
    for index, name in enumerate(order):
        layer = layers[name]
        for target, opaque in layer['removals']:
            state = {p: v for p, v in state.items() if not (
                (p == target and not opaque) or p.startswith(target + '/') or (not target and opaque))}
        for p, info in layer['changes'].items():
            if info['kind'] != 'directory':
                state = {q: v for q, v in state.items() if not q.startswith(p + '/')}
            state[p] = dict(info, layer_index=index)
    final = {}
    for path in selected:
        if path not in state:
            continue
        for n in range(1, len(path.split('/'))):
            ancestor = '/'.join(path.split('/')[:n])
            if ancestor in state and state[ancestor]['kind'] != 'directory':
                raise InventoryError('selected file has non-directory ancestor')
        if state[path]['kind'] != 'regular':
            raise InventoryError('selected file is not regular')
        final[path] = state[path]
    if DB_PATH not in final:
        raise InventoryError('installed APK database absent from final view')
    packages = parse_apk(final[DB_PATH]['content'])
    return dict(schema_version=1, image=metadata, package_count=len(packages),
                packages=packages, selected_files=final,
                missing_notice_paths=sorted(selected - set(final)),
                layer_order=order, stream_bytes=reader.count,
                config_parsed=False, container_executed=False, legal_clearance=False,
                coverage_complete=False)


class InventoryError(ValueError):
    """Input cannot support a bounded, unambiguous inventory."""


def public_notice(path):
    return (path.startswith('usr/share/licenses/') or
            path.startswith('usr/share/doc/')) and bool(re.fullmatch(
                r'(LICENSE|COPYING|COPYRIGHT|NOTICE)([._-][A-Za-z0-9._-]+)?',
                path.rsplit('/', 1)[-1], re.I))


def parse_apk(data):
    """Parse all installed records; never silently discard malformed/duplicate APKs."""
    if not data or len(data) > MAX_SELECTED:
        raise InventoryError('empty/oversized installed database')
    packages, seen = [], set()
    try:
        records = re.split(r'\n\s*\n', data.decode('utf-8').strip())
        for record in records:
            fields, notices = {}, []
            directory, file_count = '', 0
            for line in record.splitlines():
                if len(line) < 2 or line[1] != ':':
                    raise InventoryError('malformed APK field')
                key, value = line[0], line[2:]
                if key == 'F':
                    directory = safe_path(value) if value else ''
                elif key == 'R':
                    path = safe_path((directory + '/' if directory else '') + value)
                    file_count += 1
                    if public_notice(path):
                        notices.append(path)
                elif key in 'afMZ':  # repeatable file metadata, not package identity
                    continue
                elif key in fields:
                    raise InventoryError('duplicate APK field')
                else:
                    fields[key] = value
            for key in ('P', 'V', 'A', 'L', 'o'):
                if not fields.get(key):
                    raise InventoryError('required APK field absent')
            if not re.fullmatch(r'[a-zA-Z0-9][a-zA-Z0-9+_.-]*', fields['P']):
                raise InventoryError('invalid APK name')
            if fields['P'] in seen:
                raise InventoryError('duplicate installed APK name')
            if fields.get('c') and not re.fullmatch(r'[0-9a-f]{40}', fields['c']):
                raise InventoryError('malformed APK source commit')
            seen.add(fields['P'])
            packages.append(dict(name=fields['P'], version=fields['V'],
                                 architecture=fields['A'], license=fields['L'],
                                 origin=fields['o'], source_commit=fields.get('c'),
                                 upstream_url=fields.get('U'), checksum=fields.get('C'),
                                 dependencies=fields.get('D', '').split(),
                                 installed_file_count=file_count,
                                 notice_paths=sorted(set(notices))))
    except (UnicodeError, KeyError) as exc:
        raise InventoryError('malformed installed APK database') from exc
    return sorted(packages, key=lambda p: p['name'])
